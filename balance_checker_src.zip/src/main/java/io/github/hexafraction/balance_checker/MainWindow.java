package io.github.hexafraction.balance_checker;

import com.google.common.base.Joiner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.util.ParameterFormatter;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;


import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.MalformedInputException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

/**
 * Created by Andrey Akhmetov on 6/26/2016.
 */
public class MainWindow {
    JPanel contentPane;
    private JButton pasteAddressesButton;
    private JButton loadFromFileButton;
    private JPanel btnsPane;
    private JTextArea donationsNotif;
    private JTable tbl;
    private JButton clearListButton;
    private JButton getBalancesButton;
    private TableModel dm;

    public MainWindow() {
        clearListButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dm.addresses.clear();
                dm.fireTableDataChanged();
                super.mouseClicked(e);
            }
        });
        loadFromFileButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JFileChooser jfc = new JFileChooser();
                int rs = jfc.showOpenDialog(contentPane);
                if (rs == JFileChooser.APPROVE_OPTION) {
                    File f = jfc.getSelectedFile();
                    try {
                        List<String> lines = Files.readAllLines(f.toPath(), Charset.defaultCharset());
                        loadAddresses(lines.toArray(new String[0]));

                    } catch (MalformedInputException e1) {
                        JOptionPane.showMessageDialog(contentPane, "Error reading file. It's probably not a text file, or is corrupt.");
                    } catch (IOException e1) {
                        JOptionPane.showMessageDialog(contentPane, "Error reading file: " + e1.getClass() + ": " + e1.getMessage());
                    }
                }

            }
        });
        pasteAddressesButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                AddressInput dialog = new AddressInput();
                dialog.pack();
                dialog.setModal(true);
                dialog.setVisible(true);
                String[] addrs = dialog.area.getText().split("[\n,\r\\W]");
                loadAddresses(addrs);
            }
        });
        getBalancesButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                getBalancesButton.setEnabled(false);
                pasteAddressesButton.setEnabled(false);
                loadFromFileButton.setEnabled(false);
                clearListButton.setEnabled(false);
                SwingWorker<Exception, Double> worker = new SwingWorker<Exception, Double>() {
                    int listPtr = 0;
                    @Override
                    protected Exception doInBackground() throws Exception {
                        for(int i = 0; i < dm.addresses.size(); i+=20){
                            try {
                                doRequest(dm.addresses.subList(i, Math.min(i + 20, dm.addresses.size())));
                            } catch (Exception e) {
                                return e;
                            }
                        }
                        return null;
                    }

                    private void doRequest(List<Address> sublist) throws Exception {
                        String concatenated = Joiner.on(',').join(sublist);
                        HttpClient client = new HttpClient();
                        HttpMethod method = new GetMethod("http://btc.blockr.io/api/v1/address/balance/"+concatenated);
                        System.out.println("http://btc.blockr.io/api/v1/address/balance/"+concatenated);
                        //publish(Collections.nCopies(sublist.size(), 125.2).toArray(new Double[0]));
                        try {
                            client.executeMethod(method);

                            if (method.getStatusCode() == HttpStatus.SC_OK) {
                                String response = method.getResponseBodyAsString();
                                JSONObject jo = new JSONObject(response);
                                JSONArray arr = jo.getJSONArray("data");
                                int len = arr.length();
                                Double[] pubval = new Double[len];
                                for(int i = 0; i < len; i++){
                                    pubval[i] = arr.getJSONObject(i).getDouble("balance");
                                }
                                publish(pubval);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                            throw e;
                        } finally {
                            method.releaseConnection();
                        }
                    }

                    @Override
                    protected void process(List<Double> chunks) {
                        for(double d : chunks){
                            Address addr = dm.addresses.get(listPtr);
                            addr.validBalance = true;
                            addr.balance = d;
                            listPtr++;
                        }
                        dm.fireTableDataChanged();
                        super.process(chunks);
                    }

                    @Override
                    protected void done() {
                        try {
                            if(get()!=null){
                                JOptionPane.showMessageDialog(contentPane, "Error reading file: " + get().getClass() + ": " + get().getMessage());
                            }
                        } catch (InterruptedException e1) {
                            e1.printStackTrace();
                        } catch (ExecutionException e1) {
                            e1.printStackTrace();
                        }
                        getBalancesButton.setEnabled(true);
                        pasteAddressesButton.setEnabled(true);
                        loadFromFileButton.setEnabled(true);
                        clearListButton.setEnabled(true);
                    }
                };
                worker.execute();
            }
        });
    }

    private void loadAddresses(String[] lines) {
        for (String l : lines) {
            String addr = l.replaceAll("[,\\W\\t\n\r]", "");
            if(addr.isEmpty()) continue;
            if (!addr.matches("^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$")) {
                JOptionPane.showMessageDialog(contentPane, "Invalid address: " + addr);
                break;
            }
            Address a = new Address(addr);
            if(!dm.addresses.contains(a)) dm.addresses.add(new Address(addr));

        }
        dm.fireTableDataChanged();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BTC balance checker");
        frame.setContentPane(new MainWindow().contentPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        donationsNotif = new JTextArea("Tips: 1CF4GhXX1RhCaGzWztgE1YZZUcSpoqTbsJ");
        //donationsNotif.setFont(new Font("monospaced", Font.ITALIC, 12));
        dm = new TableModel();
        tbl = new JTable(dm);
        tbl.getColumnModel().getColumn(0).setPreferredWidth(100);
        tbl.getColumnModel().getColumn(1).setPreferredWidth(10);
    }

    class TableModel extends AbstractTableModel {
        List<Address> addresses = new ArrayList<>();

        @Override
        public int getRowCount() {
            return addresses.size();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public String getColumnName(int column) {
            return (column == 0) ? "Address" : "Balance";
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            if (columnIndex == 0) return addresses.get(rowIndex).addr;
            else return addresses.get(rowIndex).validBalance ? addresses.get(rowIndex).balance : null;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return (columnIndex == 0) ? String.class : Double.class;
        }
    }
}
